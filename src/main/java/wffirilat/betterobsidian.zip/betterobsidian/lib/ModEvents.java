package wffirilat.betterobsidian.lib;

import java.util.Random;

import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraftforge.event.entity.player.BonemealEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import wffirilat.betterobsidian.Blocks.ModBlocks;
import wffirilat.betterobsidian.gen.WorldGenHugeBlackMushroom;
import cpw.mods.fml.common.eventhandler.Event.Result;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;

public class ModEvents {
	@SubscribeEvent
	public void bonemeal(BonemealEvent e) {
		if (e.block == ModBlocks.blueMushroom) {
			WorldGenerator mushroomGenerator = new WorldGenHugeBlackMushroom();
			mushroomGenerator.generate(e.world, new Random(), e.x, e.y, e.z);
		}
	}

	@SubscribeEvent
	public void useItem(PlayerInteractEvent e) {}
}
