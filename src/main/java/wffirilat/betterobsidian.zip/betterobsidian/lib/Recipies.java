package wffirilat.betterobsidian.lib;

import wffirilat.betterobsidian.Blocks.ModBlocks;
import wffirilat.betterobsidian.Items.ModItems;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import cpw.mods.fml.common.registry.GameRegistry;

public class Recipies {
	public static void init() {
		GameRegistry.addSmelting(new ItemStack(ModBlocks.cobblesidian), new ItemStack(Blocks.obsidian), 0.5f);
		GameRegistry.addSmelting(new ItemStack(Blocks.obsidian), new ItemStack(ModItems.obsidianIngot), 0.5f);

		GameRegistry.addRecipe(new ItemStack(ModBlocks.cobblesidian, 4), "OO", "OO", 'O', Blocks.obsidian);
		GameRegistry.addRecipe(new ItemStack(ModBlocks.obsidianBricks, 4), "OOO", "OOO", "OOO", 'O', ModItems.obsidianIngot);
		GameRegistry.addRecipe(new ItemStack(Blocks.bedrock), "OOO", "ODO", "OOO", 'O', ModBlocks.obsidianBricks, 'D', Blocks.diamond_block);
		// GameRegistry.addRecipe(new ItemStack(Blocks.bedrock, 8), "DOD",
		// "OOO", "DOD", 'O', ModBlocks.obsidianBricks, 'D', Blocks.bedrock);
		GameRegistry.addRecipe(new ItemStack(Blocks.bedrock), "BB", "BB", 'B', ModItems.bedrockShard);
		GameRegistry.addRecipe(new ItemStack(ModBlocks.voidBlock, 1), "OOO", "OOO", "OOO", 'O', ModItems.voidOrb);
		GameRegistry.addRecipe(new ItemStack(ModBlocks.compressedCobble), "ccc", "ccc", "ccc", 'c', Blocks.cobblestone);
		GameRegistry.addRecipe(new ItemStack(ModBlocks.superCompressedCobble), "ccc", "ccc", "ccc", 'c', ModBlocks.compressedCobble);
		GameRegistry.addRecipe(new ItemStack(Items.saddle), "IDI", "I I", "   ", 'I', Items.leather, 'D', Items.iron_ingot);
		GameRegistry.addRecipe(new ItemStack(ModItems.magic), "rr", "rr", 'r', ModItems.rainbowShard);
		GameRegistry.addRecipe(new ItemStack(ModItems.bigMagic), "ccc", "ccc", "ccc", 'c', ModItems.magic);
		GameRegistry.addRecipe(new ItemStack(ModItems.hugeMagic), "ccc", "ccc", "ccc", 'c', ModItems.bigMagic);

		GameRegistry.addRecipe(new ItemStack(ModItems.obsidianPick), "III", " S ", " S ", 'I', ModItems.obsidianIngot, 'S', Items.diamond);
		GameRegistry.addRecipe(new ItemStack(ModItems.obsidianAxe), "II ", "IS ", " S ", 'I', ModItems.obsidianIngot, 'S', Items.diamond);
		GameRegistry.addRecipe(new ItemStack(ModItems.obsidianShovel), " I ", " S ", " S ", 'I', ModItems.obsidianIngot, 'S', Items.diamond);
		GameRegistry.addRecipe(new ItemStack(ModItems.obsidianSword), " I ", " I ", " S ", 'I', ModItems.obsidianIngot, 'S', Items.diamond);
		GameRegistry.addRecipe(new ItemStack(ModItems.obsidianBoots), "   ", "I I", "I I", 'I', ModItems.obsidianIngot);
		GameRegistry.addRecipe(new ItemStack(ModItems.obsidianHelmet), "IDI", "I I", "   ", 'I', ModItems.obsidianIngot, 'D', Items.diamond);
		GameRegistry.addRecipe(new ItemStack(ModItems.obsidianLeggings), "IDI", "I I", "I I", 'I', ModItems.obsidianIngot, 'D', Items.diamond);
		GameRegistry.addRecipe(new ItemStack(ModItems.obsidianChestplate), "I I", "IDI", "IDI", 'I', ModItems.obsidianIngot, 'D', Items.diamond);
		GameRegistry.addRecipe(new ItemStack(ModItems.bedrockPick), "III", " S ", " S ", 'I', Blocks.bedrock, 'S', Items.stick);
		GameRegistry.addRecipe(new ItemStack(ModItems.bedrockAxe), "II ", "IS ", " S ", 'I', Blocks.bedrock, 'S', Items.stick);
		GameRegistry.addRecipe(new ItemStack(ModItems.bedrockShovel), " I ", " S ", " S ", 'I', Blocks.bedrock, 'S', Items.stick);
		GameRegistry.addRecipe(new ItemStack(ModItems.bedrockSword), " I ", " I ", " S ", 'I', Blocks.bedrock, 'S', Items.stick);
		GameRegistry.addRecipe(new ItemStack(ModItems.bedrockBoots), "   ", "I I", "I I", 'I', Blocks.bedrock);
		GameRegistry.addRecipe(new ItemStack(ModItems.bedrockHelmet), "III", "I I", "   ", 'I', Blocks.bedrock);
		GameRegistry.addRecipe(new ItemStack(ModItems.bedrockLeggings), "III", "I I", "I I", 'I', Blocks.bedrock);
		GameRegistry.addRecipe(new ItemStack(ModItems.bedrockChestplate), "I I", "III", "III", 'I', Blocks.bedrock);
		GameRegistry.addRecipe(new ItemStack(ModItems.rainbowPick), "III", " S ", " S ", 'I', ModItems.rainbowShard, 'S', Items.stick);
		GameRegistry.addRecipe(new ItemStack(ModItems.rainbowAxe), "II ", "IS ", " S ", 'I', ModItems.rainbowShard, 'S', Items.stick);
		GameRegistry.addRecipe(new ItemStack(ModItems.rainbowShovel), " I ", " S ", " S ", 'I', ModItems.rainbowShard, 'S', Items.stick);
		GameRegistry.addRecipe(new ItemStack(ModItems.rainbowSword), " I ", " I ", " S ", 'I', ModItems.rainbowShard, 'S', Items.stick);
		
		GameRegistry.addShapelessRecipe(new ItemStack(ModItems.beefSandwich), Items.bread, Items.cooked_beef);
		GameRegistry.addShapelessRecipe(new ItemStack(ModItems.rope), Items.string, Items.string, Items.string);
	}
}