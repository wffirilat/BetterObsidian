package wffirilat.betterobsidian.lib;

public class Constants {
	
	public final static String MODID = "betterobsidian";
	public final static String MODNAME = "Better Obsidian";
	public final static String VERSION = "0.1.4";
	
}
