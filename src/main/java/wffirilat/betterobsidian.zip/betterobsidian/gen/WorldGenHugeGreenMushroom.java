package wffirilat.betterobsidian.gen;

import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;
import wffirilat.betterobsidian.Blocks.ModBlocks;

public class WorldGenHugeGreenMushroom extends WorldGenerator {

	public Block stem = ModBlocks.blueMushroomStem;
	public Block cap = ModBlocks.blueMushroomCap;

	@Override
	public boolean generate(World w, Random r, int x, int y, int z) {
		if (!w.isRemote) {
			int stemHeight = r.nextInt(3) + 4;
			for (int i1 = 0; i1 < stemHeight; i1++) {
				w.setBlock(x, y + i1, z, stem);
			}
			for (int i1 = -3; i1 <= 3; i1++) {
				for (int j1 = -2; j1 <= 0; j1++) {
					for (int k1 = -3; k1 <= 3; k1++) {
						int i = Math.abs(i1);
						int k = Math.abs(k1);
						if (j1 == -2) {
							if (i == 3 ^ k == 3) {
								w.setBlock(x + i1, y + j1 + stemHeight, z + k1,
										cap);
							}
						}
						if (j1 == -1) {
							if (i >= 2 || k >= 2) {
								if ((i + k) <= 4) {
									w.setBlock(x + i1, y + j1 + stemHeight, z
											+ k1, cap);
								}
							}
						}
						if (j1 == 0) {
							if (i < 2 && k < 2) {
								w.setBlock(x + i1, y + j1 + stemHeight, z + k1,
										cap);
							}
						}
					}
				}
			}
		}
		return true;
	}
}
