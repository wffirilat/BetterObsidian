package wffirilat.betterobsidian.gen;

import wffirilat.betterobsidian.BetterObsidian;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.biome.WorldChunkManagerHell;
import net.minecraft.world.chunk.IChunkProvider;

public class WorldProviderVoid extends WorldProvider {

	public void registerWorldChunkManager() {
		this.worldChunkMgr = new WorldChunkManagerHell(BiomeGenBase.deepOcean, 0.1f);
		this.dimensionId = BetterObsidian.dimensionId;
	}

	public IChunkProvider createChunkGenerator() {
		return new ChunkProviderVoid(worldObj, worldObj.getSeed(), true);
	}

	public String getDimensionName() {
		return "VoidDimension";
	}
}
