package wffirilat.betterobsidian.gen;

import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;
import wffirilat.betterobsidian.Blocks.ModBlocks;

public class WorldGenHugePinkMushroom extends WorldGenerator {

	public Block stem = ModBlocks.blueMushroomStem;
	public Block cap = ModBlocks.blueMushroomCap;

	@Override
	public boolean generate(World w, Random r, int x, int y, int z) {
		if (!w.isRemote) {
			int stemHeight = r.nextInt(3) + 3;
			for (int i1 = 0; i1 < stemHeight; i1++) {
				w.setBlock(x, y + i1, z, stem);
			}
			for (int i1 = -3; i1 <= 3; i1++) {
				for (int j1 = 0; j1 <= 1; j1++) {
					for (int k1 = -3; k1 <= 3; k1++) {
						if (j1 == 0) {
							if (Math.abs(i1) != 3 || Math.abs(k1) != 3) {
								w.setBlock(x + i1, y + j1 + stemHeight, z + k1,
										cap);
							}
						}
						if (j1 == 1) {
							if (((Math.abs(i1) == 2 ^ Math.abs(k1) == 2)
									|| (Math.abs(i1) == 1 && Math.abs(k1) == 1))
									&& (Math.abs(i1) <= 2 && Math.abs(k1) <= 2)) {
								w.setBlock(x + i1, y + j1 + stemHeight, z + k1,
										cap);
							}
						}
					}
				}
			}
		}
		return true;
	}
}
