package wffirilat.betterobsidian.gen;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;

public class WorldGenSphere extends WorldGenerator {

	private Block block;
	private int radius;

	public WorldGenSphere(Block b, int radius) {
		super();
		this.block = b;
		this.radius = radius;
	}

	@Override
	public boolean generate(World w, Random p_76484_2_, int x, int y, int z) {
		for (int i = -radius; i <= radius; i++) {
			for (int j = -radius; j <= radius; j++) {
				for (int k = -radius; k <= radius; k++) {
					if (Math.sqrt(i * i + j * j + k * k) <= radius) {
						w.setBlock(x + i, y + j, z + k, block);
					}
				}
			}
		}
		return false;
	}

}
