package wffirilat.betterobsidian.gen;

import java.util.Random;

import wffirilat.betterobsidian.Blocks.ModBlocks;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;

public class WorldGenHugeBlueMushroom extends WorldGenerator {

	@Override
	public boolean generate(World w, Random rand, int x, int y, int z) {
		if (!w.isRemote) {
			int stemHeight = rand.nextInt(3) + 4;
			int capSize = stemHeight == 4 ? 2 : 3;// rand.nextInt(2)+2;
			for (int i1 = -capSize - 1; i1 <= capSize + 1; i1++) {
				for (int j1 = 1; j1 <= (stemHeight + 1); j1++) {
					for (int k1 = -capSize - 1; k1 <= capSize + 1; k1++) {
						if (w.getBlock(x + i1, y + j1, z + k1) != Blocks.air) {
							return false;
						}
					}
				}
			}
			for (int i1 = 0; i1 < stemHeight; i1++) {
				w.setBlock(x, y + i1, z, ModBlocks.blueMushroomStem);
			}
			for (int i1 = -capSize; i1 <= capSize; i1++) {
				for (int j1 = -capSize; j1 <= capSize; j1++) {
					if (!(Math.abs(i1) == capSize && Math.abs(j1) == capSize)) {
						w.setBlock(
								x + i1,
								y
										+ stemHeight
										+ ((Math.abs(i1) == 3 || Math.abs(j1) == 3) ? -1
												: 0), z + j1,
								ModBlocks.blueMushroomCap);
					}
				}
			}
		}
		return true;
	}
}
