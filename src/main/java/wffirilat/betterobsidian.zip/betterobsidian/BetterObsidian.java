package wffirilat.betterobsidian;

import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.common.MinecraftForge;
import wffirilat.betterobsidian.Blocks.ModBlocks;
import wffirilat.betterobsidian.Items.ModItems;
import wffirilat.betterobsidian.Mobs.ModMobs;
import wffirilat.betterobsidian.gen.WorldProviderVoid;
import wffirilat.betterobsidian.lib.Constants;
import wffirilat.betterobsidian.lib.ModEvents;
import wffirilat.betterobsidian.lib.OreGenerators;
import wffirilat.betterobsidian.lib.Recipies;
import wffirilat.betterobsidian.proxy.CommonProxy;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.Mod.Instance;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = Constants.MODID, name = Constants.MODNAME, version = Constants.VERSION)
public class BetterObsidian {

	@Instance(Constants.MODID)
	public static BetterObsidian modInstance;

	public static final int dimensionId = 8;

	public static ModEvents events = new ModEvents();

	@SidedProxy(clientSide = "wffirilat.betterobsidian.proxy.ClientProxy", serverSide = "wffirilat.betterobsidian.proxy.CommonProxy")
	public static CommonProxy proxy;

	@EventHandler()
	public void preInit(FMLPreInitializationEvent event) {

		FMLCommonHandler.instance().bus().register(events);
		MinecraftForge.EVENT_BUS.register(events);

		ModBlocks.init();
		ModItems.init();
		Recipies.init();
		OreGenerators.init();
		ModMobs.init();

		DimensionManager.registerProviderType(dimensionId,
				WorldProviderVoid.class, false);
		DimensionManager.registerDimension(dimensionId, dimensionId);

		proxy.registerRenderers();

	}

	@EventHandler()
	public void init(FMLInitializationEvent event) {

	}

	@EventHandler()
	public void postInit(FMLPostInitializationEvent event) {

	}
}
