package wffirilat.betterobsidian.Blocks;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;

public class TileEntityTeleport extends TileEntity {

	public TileEntityTeleport() {
//		xOff = 0;
//		yOff = 0;
//		zOff = 0;

	}

	public void readFromNBT(NBTTagCompound nbt) {
		super.readFromNBT(nbt);
		xOff = nbt.getInteger("xOffset");
		yOff = nbt.getInteger("yOffset");
		zOff = nbt.getInteger("zOffset");
	}

	public void writeToNBT(NBTTagCompound nbt) {
		super.writeToNBT(nbt);
		nbt.setInteger("xOffset", xOff);
		nbt.setInteger("yOffset", yOff);
		nbt.setInteger("zOffset", zOff);
	}

	@Override
	public Packet getDescriptionPacket() {
		NBTTagCompound tileTag = new NBTTagCompound();
		this.writeToNBT(tileTag);
		return new S35PacketUpdateTileEntity(this.xCoord, this.yCoord,
				this.zCoord, 0, tileTag);
	}

	@Override
	public void onDataPacket(NetworkManager net, S35PacketUpdateTileEntity pkt) {
		this.readFromNBT(pkt.func_148857_g());
	}

	private int xOff;
	private int yOff;
	private int zOff;

	public int getxOff() {
		return xOff;
	}

	public void setxOff(int xOff) {
		this.xOff = xOff;
	}

	public int getyOff() {
		return yOff;
	}

	public void setyOff(int yOff) {
		this.yOff = yOff;
	}

	public int getzOff() {
		return zOff;
	}

	public void setzOff(int zOff) {
		this.zOff = zOff;
	}

}
