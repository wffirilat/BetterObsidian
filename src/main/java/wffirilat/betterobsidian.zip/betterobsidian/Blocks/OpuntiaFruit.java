package wffirilat.betterobsidian.Blocks;

import java.util.Random;

import net.minecraft.block.BlockCactus;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import wffirilat.betterobsidian.Items.ModItems;
import wffirilat.betterobsidian.lib.Constants;
import cpw.mods.fml.common.registry.GameRegistry;

public class OpuntiaFruit extends BlockCactus {

	public String name = "OpuntiaFruit";

	public OpuntiaFruit() {

		super();
		setBlockName(Constants.MODID + "_" + name);
		setBlockTextureName(Constants.MODID + ":" + name);
		setCreativeTab(CreativeTabs.tabBlock);
		GameRegistry.registerBlock(this, name);
		this.setTickRandomly(true);
	}

	public void onEntityCollidedWithBlock(World world, int x, int y, int z, Entity entity) {
		entity.attackEntityFrom(DamageSource.cactus, 6.0F);
	}

	public boolean canBlockStay(World world, int x, int y, int z) {
		return world.getBlock(x, y - 1, z) == ModBlocks.petroOpuntia;
	}

	public void updateTick(World world, int x, int y, int z, Random rand) {
		int meta = world.getBlockMetadata(x, y, z);

		if (meta == 15) {
			world.setBlock(x, y, z, Blocks.air);
		} else {
			world.setBlockMetadataWithNotify(x, y, z, meta + 1, 4);
		}
	}
	
	public Item getItemDropped(int p_149650_1_, Random rand, int fortune) {
		return ModItems.opuntiaSeed;
	}
}
