package wffirilat.betterobsidian.Blocks;

import java.util.Random;

import net.minecraft.block.BlockCactus;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import wffirilat.betterobsidian.lib.Constants;
import cpw.mods.fml.common.registry.GameRegistry;

public class PetroOpuntia extends BlockCactus {

	public String name = "petroOpuntia";

	public PetroOpuntia() {

		super();
		setBlockName(Constants.MODID + "_" + name);
		setBlockTextureName(Constants.MODID + ":" + name);
		setCreativeTab(CreativeTabs.tabBlock);
		GameRegistry.registerBlock(this, name);
		this.setTickRandomly(true);
	}

	public void onEntityCollidedWithBlock(World world, int x, int y, int z, Entity entity) {
		entity.attackEntityFrom(DamageSource.cactus, 4.0F);
	}

	public boolean canBlockStay(World world, int x, int y, int z) {
		return world.getBlock(x, y - 1, z).getMaterial().isSolid();
	}

	/**
	 * Ticks the block if it's been scheduled
	 */
	public void updateTick(World world, int x, int y, int z, Random rand) {
		if (world.isAirBlock(x, y + 1, z)) {
			int height;

			for (height = 1; world.getBlock(x, y - height, z) == this; ++height) {
				;
			}
			int meta = world.getBlockMetadata(x, y, z);

			if (meta == 15) {
				if (height < 3) {
					world.setBlock(x, y + 1, z, this);
				} else if (height == 3) {
					world.setBlock(x, y + 1, z, ModBlocks.opuntiaFruit);
				}
			} else {
				world.setBlockMetadataWithNotify(x, y, z, meta + 1, 4);
			}
		}
	}
}
