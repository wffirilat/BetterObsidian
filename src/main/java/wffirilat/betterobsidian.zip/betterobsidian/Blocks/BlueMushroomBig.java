package wffirilat.betterobsidian.Blocks;

import java.util.Random;

import wffirilat.betterobsidian.gen.WorldGenHugeBlueMushroom;
import wffirilat.betterobsidian.lib.Constants;
import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBush;
import net.minecraft.block.BlockMushroom;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenerator;

public class BlueMushroomBig extends BlockMushroom {

	public String name = "blueMushroomBig";

	public BlueMushroomBig() {

		super();
		setBlockName(Constants.MODID + "_" + name);
		setBlockTextureName(Constants.MODID + ":" + name);
		setCreativeTab(CreativeTabs.tabBlock);
        float f = 0.4F;
        this.setBlockBounds(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, f * 2.0F, 0.5F + f);
		GameRegistry.registerBlock(this, name);

	}
	
	public boolean onBlockActivated(World w, int par2, int par3, int par4, EntityPlayer p, int par6, float par7, float par8, float par9){
		WorldGenerator mushroomGenerator = new WorldGenHugeBlueMushroom();
		mushroomGenerator.generate(w, w.rand, par2, par3, par4);
		return true;	
    }

}