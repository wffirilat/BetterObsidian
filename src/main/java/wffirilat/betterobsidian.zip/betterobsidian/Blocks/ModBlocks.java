package wffirilat.betterobsidian.Blocks;

import net.minecraft.block.Block;
import net.minecraft.block.BlockStairs;
import net.minecraft.init.Blocks;
import cpw.mods.fml.common.registry.GameRegistry;

public final class ModBlocks {

	public static Block cobblesidian;
	public static Block obsidianBricks;
	public static Block bedrockOre;
	public static Block voidPortal;
	public static Block voidBlock;
	public static Block fossilRainbow;
	public static Block obsidianStair;
	public static Block obsidianSlab;
	public static Block obsidianSlabDouble;
	public static Block blueMushroomStem;
	public static Block blueMushroomCap;
	public static Block blueMushroom;
	public static Block blueMushroomBig;
	public static Block glowAir;
	public static Block mageFire;
	public static Block teleport;
	public static Block compressedCobble;
	public static Block superCompressedCobble;
	public static Block TEST;
	public static Block chlorophyte;
	public static Block netherDiamond;
	public static Block petroOpuntia;
	public static Block opuntiaFruit;

	public static void init() {
		cobblesidian = new Cobblesidian().setHardness(10.0f).setResistance(2000.0f);
		obsidianBricks = new ObsidianBricks().setHardness(50.0f).setResistance(2000.0f);
		bedrockOre = new BedrockOre().setHardness(100f).setResistance(6000000f);
		voidPortal = new BlockPortalVoid();
		voidBlock = new VoidBlock();
		fossilRainbow = new RainbowOre();//.setLightLevel(1.0f);
		obsidianStair = new StairsHelper("obsidianStair", Blocks.obsidian, 0);
		obsidianSlab = new ObsidianSlab().setHardness(10.0f).setResistance(2000.0f);
		obsidianSlabDouble = new ObsidianSlabDouble().setHardness(10.0f).setResistance(2000.0f);
		blueMushroomStem = new BlueMushroomStem();
		blueMushroomCap = new BlueMushroomCap();
		blueMushroom = new BlueMushroom();
		blueMushroomBig = new BlueMushroomBig();
		glowAir = new GlowAir().setLightLevel(1f);
		teleport = new TeleportBlock();
		compressedCobble = new CompressedCobble().setHardness(8.0f).setResistance(40f);
		superCompressedCobble = new SuperCompressedCobble().setHardness(32.0f).setResistance(160f);
		mageFire = new MageFire().setLightLevel(1.0f);
		TEST = new TEST();
		chlorophyte = new Chlorophyte();
		netherDiamond = new NetherDiamond().setHardness(4.0f);
		petroOpuntia = new PetroOpuntia().setHardness(4.0f);
		opuntiaFruit = new OpuntiaFruit().setHardness(2.0f);
		GameRegistry.registerTileEntity(TileEntityTeleport.class, "TeleportTile");
	}
}