package wffirilat.betterobsidian.Blocks;

import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.world.World;
import wffirilat.betterobsidian.lib.Constants;
import cpw.mods.fml.common.registry.GameRegistry;

public class Chlorophyte extends Block {

	public String name = "chlorophyte";

	public Chlorophyte() {

		super(Material.rock);
		this.setTickRandomly(true);
		setBlockName(Constants.MODID + "_" + name);
		setBlockTextureName(Constants.MODID + ":" + name);
		setCreativeTab(CreativeTabs.tabBlock);
		GameRegistry.registerBlock(this, name);

	}
	int getContigCount(World w, int x, int y, int z){
		for(int i = -1;i<2;i++){}
		return 0;
	}

	@Override
	public void updateTick(World w, int x, int y, int z, Random r) {
		int face = r.nextInt(6);
		switch (face) {
			case 0:
				if (w.getBlock(x - 1, y, z) == Blocks.cobblestone) {
					w.setBlock(x - 1, y, z, ModBlocks.chlorophyte);
				}
			case 1:
				if (w.getBlock(x + 1, y, z) == Blocks.cobblestone) {
					w.setBlock(x + 1, y, z, ModBlocks.chlorophyte);
				}
			case 2:
				if (w.getBlock(x, y - 1, z) == Blocks.cobblestone) {
					w.setBlock(x, y - 1, z, ModBlocks.chlorophyte);
				}
			case 3:
				if (w.getBlock(x, y + 1, z) == Blocks.cobblestone) {
					w.setBlock(x, y + 1, z, ModBlocks.chlorophyte);
				}
			case 4:
				if (w.getBlock(x, y, z - 1) == Blocks.cobblestone) {
					w.setBlock(x, y, z - 1, ModBlocks.chlorophyte);
				}
			case 5:
				if (w.getBlock(x, y, z + 1) == Blocks.cobblestone) {
					w.setBlock(x, y, z + 1, ModBlocks.chlorophyte);
				}
		}
	}
}