package wffirilat.betterobsidian.Blocks;

import wffirilat.betterobsidian.lib.Constants;
import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.DamageSource;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class VoidBlock extends Block {

	public String name = "voidBlock";

	public VoidBlock() {

		super(Material.rock);
		this.slipperiness = 0.1f;
		setBlockName(Constants.MODID + "_" + name);
		setBlockTextureName(Constants.MODID + ":" + name);
		setCreativeTab(CreativeTabs.tabBlock);
		GameRegistry.registerBlock(this, name);

	}

	@Override
	public void onEntityCollidedWithBlock(World par1World, int par2, int par3, int par4, Entity par5Entity) {
		par5Entity.attackEntityFrom(DamageSource.cactus, 5.0F);
	}

	public boolean onBlockActivated(World w, int x, int y, int z, EntityPlayer p, int par6, float par7, float par8, float par9) {
		if (!w.isRemote) {
			w.setBlock(x, y, z, Blocks.air);
			for (int i1 = -3; i1 <= 3; i1++) {
				for (int j1 = 3; j1 >= -3; j1--) {
					for (int k1 = -3; k1 <= 3; k1++) {
						if ((int) y + j1 > 0 || (i1 == 0 && j1 == -1 && k1 == 0)) {
							if (!p.capabilities.isCreativeMode) {
								p.inventory.addItemStackToInventory(new ItemStack(Item.getItemFromBlock(w.getBlock((int) x + i1, (int) y + j1, (int) z + k1)), 1, w.getBlockMetadata((int) x + i1, (int) y + j1, (int) z + k1)));
							}
							w.setBlock((int) x + i1, (int) y + j1, (int) z + k1, Blocks.air);

						}
						if ((i1 == 0 && j1 == -1 && k1 == 0)) {

						}
					}
				}
			}
			if ((w.getBlock((int) x, (int) y - 1, (int) z)) == Blocks.bedrock && ((int) y - 1 == 0)) {
				w.setBlock((int) x, (int) y - 1, (int) z, ModBlocks.voidPortal, 0, 2);
			}
			p.inventoryContainer.detectAndSendChanges();
		}
		return true;
	}

	public AxisAlignedBB getCollisionBoundingBoxFromPool(World w, int x, int y, int z) {
		float f = 0.0625F;
		return AxisAlignedBB.getBoundingBox((double) ((float) x + f), (double) ((float) y + f), (double) ((float) z + f), (double) ((float) (x + 1) - f), (double) ((float) (y + 1) - f), (double) ((float) (z + 1) - f));
	}

}
