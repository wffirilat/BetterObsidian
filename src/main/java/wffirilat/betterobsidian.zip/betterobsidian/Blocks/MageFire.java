package wffirilat.betterobsidian.Blocks;

import net.minecraft.block.BlockFire;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import wffirilat.betterobsidian.lib.Constants;
import cpw.mods.fml.common.registry.GameRegistry;

public class MageFire extends BlockFire {

	public String name = "mageFire";

	public MageFire() {

		super();
		setBlockName(Constants.MODID + "_" + name);
		setBlockTextureName(Constants.MODID + ":" + name);
		// setCreativeTab(CreativeTabs.tabBlock);
		GameRegistry.registerBlock(this, name);
	}

	public void onEntityCollidedWithBlock(World w, int x, int y, int z, Entity e) {
		if(!(e instanceof EntityPlayer)){
			e.setFire(30);
		}
	}

}