package wffirilat.betterobsidian.Blocks;

import wffirilat.betterobsidian.lib.Constants;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.BlockSlab;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.util.IIcon;

public class BlueMushroomCap extends Block {

	public String name = "BlueMushroomCap";
	@SideOnly(Side.CLIENT)
	private IIcon bottomIcon;
	@SideOnly(Side.CLIENT)
	private IIcon sideIcon;

	public BlueMushroomCap() {
		super(Material.wood);
		setBlockName(Constants.MODID + "_" + name);
		// setBlockTextureName(Constants.MODID + ":" + name);
		setCreativeTab(CreativeTabs.tabBlock);
		GameRegistry.registerBlock(this, name);
	}

	@Override
	@SideOnly(Side.CLIENT)
	public void registerBlockIcons(IIconRegister Register) {
		this.bottomIcon = Register.registerIcon(Constants.MODID + ":" + name + "Bottom");
		this.sideIcon = Register.registerIcon(Constants.MODID + ":" + name);
	}

	@Override
	public IIcon getIcon(int side, int par2) {
		return (side == 0) ? bottomIcon : sideIcon;
	}
}