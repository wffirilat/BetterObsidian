package wffirilat.betterobsidian.Blocks;

import java.util.Random;

import wffirilat.betterobsidian.Items.ModItems;
import wffirilat.betterobsidian.lib.Constants;
import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Items;
import net.minecraft.item.Item;

public class NetherDiamond extends Block {

	public String name = "netherDiamond";

	public NetherDiamond() {

		super(Material.rock);
		setBlockName(Constants.MODID + "_" + name);
		setBlockTextureName(Constants.MODID + ":" + name);
		setCreativeTab(CreativeTabs.tabBlock);
		setHarvestLevel("pickaxe", 2);
		GameRegistry.registerBlock(this, name);

	}

	public Item getItemDropped(int p_149650_1_, Random rand, int fortune) {
		return rand.nextInt(10) == 0 ? ModItems.falseEmerald : Items.diamond;
	}
}