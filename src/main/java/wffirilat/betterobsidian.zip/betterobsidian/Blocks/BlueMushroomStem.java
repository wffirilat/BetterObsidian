package wffirilat.betterobsidian.Blocks;

import wffirilat.betterobsidian.lib.Constants;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.Block;
import net.minecraft.block.BlockSlab;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.util.IIcon;

public class BlueMushroomStem extends Block {

	public String name = "blueMushroomStem";
	@SideOnly(Side.CLIENT)
	private IIcon topIcon;
	@SideOnly(Side.CLIENT)
	private IIcon sideIcon;


	public BlueMushroomStem() {

		super(Material.wood);
		setBlockName(Constants.MODID + "_" + name);
		//setBlockTextureName(Constants.MODID + ":" + name);
		setCreativeTab(CreativeTabs.tabBlock);
		GameRegistry.registerBlock(this, name);

	}
	
	@Override
	@SideOnly(Side.CLIENT)
    public void registerBlockIcons(IIconRegister Register){
		this.topIcon = Register.registerIcon(Constants.MODID + ":" + name + "Top");
		this.sideIcon = Register.registerIcon(Constants.MODID + ":" + name + "Side");

	}
	
	@Override
	public IIcon getIcon(int side, int par2){
		return (side == 1 || side == 0)? topIcon:sideIcon;
		
	}
}