package wffirilat.betterobsidian.proxy;

public class CommonProxy {
	public void registerRenderers() {
		// Nothing here as the server doesn't render graphics or entities!
	}

}
