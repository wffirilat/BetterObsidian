package wffirilat.betterobsidian.Items;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;
import wffirilat.betterobsidian.Blocks.ModBlocks;
import wffirilat.betterobsidian.lib.Constants;
import cpw.mods.fml.common.registry.GameRegistry;

public class SpellHeal extends Item {

	private String name = "healSpell";

	public SpellHeal() {

		setUnlocalizedName(Constants.MODID + "_" + name);
		setTextureName(Constants.MODID + ":" + name);
		GameRegistry.registerItem(this, name);
		setCreativeTab(CreativeTabs.tabMaterials);
		this.bFull3D = true;
	}

	int healing = 2;
	int cost = 4;

	public boolean onItemUse(ItemStack iS, EntityPlayer p, World w, int x, int y, int z, int p_77648_7_, float p_77648_8_, float p_77648_9_, float p_77648_10_) {
		if (MagicItem.expendMagic(p, cost)) {
			p.setHealth(p.getHealth()+10);
		}
		return false;
	}
}
