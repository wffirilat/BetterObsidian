package wffirilat.betterobsidian.Items;

import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTool;
import net.minecraft.world.World;
import wffirilat.betterobsidian.lib.Constants;
import cpw.mods.fml.common.registry.GameRegistry;

public class ToolVoidPick extends ItemPickaxe {

	private String name = "voidPick";

	public ToolVoidPick(ToolMaterial material) {

		super(material);
		setUnlocalizedName(Constants.MODID + "_" + name);
		setTextureName(Constants.MODID + ":" + name);
		GameRegistry.registerItem(this, name);
		setCreativeTab(CreativeTabs.tabTools);
		this.canRepair = true;
	}

	public boolean recur(World world, EntityPlayer player, int xPos, int yPos, int zPos, Block block, int iteration) {
		if (iteration <= 3) {
			if (!world.isRemote) {
				if (!(player.capabilities.isCreativeMode) && world.getBlock(xPos, yPos, zPos) == block) {
					player.inventory.addItemStackToInventory(new ItemStack(block.getItemDropped(1, itemRand, 0), block.quantityDropped(itemRand), world.getBlockMetadata(xPos, yPos, zPos)));
				}
				world.setBlock(xPos, yPos, zPos, Blocks.air);
			}
			for (int i1 = -1; i1 <= 1; i1++) {
				for (int j1 = -1; j1 <= 1; j1++) {
					for (int k1 = -1; k1 <= 1; k1++) {
						if (world.getBlock(xPos + i1, yPos + j1, zPos + k1) == block && !(i1 == 0 && j1 == 0 && k1 == 0) && yPos + j1 > 0) {
							recur(world, player, xPos + i1, yPos + j1, zPos + k1, block, iteration + 1);
						}
					}
				}
			}
			if (!world.isRemote) {
				if (yPos > 0) {
					if (!(player.capabilities.isCreativeMode) && world.getBlock(xPos, yPos, zPos) == block) {
						player.inventory.addItemStackToInventory(new ItemStack(block.getItemDropped(1, itemRand, 0), block.quantityDropped(itemRand), block.damageDropped(0)));
						world.setBlock(xPos, yPos, zPos, Blocks.air);
					}
				}
			}
		}
		return true;
	}

	public boolean onItemUse(ItemStack itemStack, EntityPlayer player, World world, int xPos, int yPos, int zPos, int p_77648_7_, float p_77648_8_, float p_77648_9_, float p_77648_10_) {
		String h = world.getBlock(xPos, yPos, zPos).getHarvestTool(world.getBlockMetadata(xPos, yPos, zPos));
		if (h == null || h == "pickaxe") {
			recur(world, player, xPos, yPos, zPos, world.getBlock(xPos, yPos, zPos), 0);
			player.inventoryContainer.detectAndSendChanges();
			return true;
		}
		return false;
	}

}
