package wffirilat.betterobsidian.Items;

import wffirilat.betterobsidian.lib.Constants;
import cpw.mods.fml.common.registry.GameRegistry;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class PortableCraftingTable extends Item {
	
    private String name = "craftingTable";
    
    public PortableCraftingTable() {
        
        setUnlocalizedName(Constants.MODID + "_" + name);
        setTextureName(Constants.MODID + ":" + name);
        GameRegistry.registerItem(this, name);
        setCreativeTab(CreativeTabs.tabTools);
    }
    
	public boolean onItemUse(ItemStack i, EntityPlayer p, World w, int x,
			int y, int z, int p_77648_7_, float p_77648_8_, float p_77648_9_,
			float p_77648_10_) {
		p.displayGUIWorkbench(x, y, z);
		return true;
	}
}
