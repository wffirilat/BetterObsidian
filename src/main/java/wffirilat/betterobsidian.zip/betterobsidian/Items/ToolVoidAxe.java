package wffirilat.betterobsidian.Items;

import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTool;
import net.minecraft.world.World;
import wffirilat.betterobsidian.lib.Constants;
import cpw.mods.fml.common.registry.GameRegistry;

public class ToolVoidAxe extends ItemAxe {

	private String name = "voidAxe";

	public ToolVoidAxe(ToolMaterial material) {

		super(material);
		setUnlocalizedName(Constants.MODID + "_" + name);
		setTextureName(Constants.MODID + ":" + name);
		GameRegistry.registerItem(this, name);
		setCreativeTab(CreativeTabs.tabTools);
	}

	public boolean recur(World w, EntityPlayer p, int x, int y, int z, Block b,
			int i) {
		if (i <= 3) {
			if (!w.isRemote) {
				if (!(p.capabilities.isCreativeMode)
						&& w.getBlock(x, y, z) == b) {
					p.inventory.addItemStackToInventory(new ItemStack(b
							.getItemDropped(1, itemRand, 0), b
							.quantityDropped(itemRand), w.getBlockMetadata(x,
							y, z)));
				}
				w.setBlock(x, y, z, Blocks.air);
			}
			for (int i1 = -1; i1 <= 1; i1++) {
				for (int j1 = -1; j1 <= 1; j1++) {
					for (int k1 = -1; k1 <= 1; k1++) {
						if (w.getBlock(x + i1, y + j1, z + k1) == b
								&& !(i1 == 0 && j1 == 0 && k1 == 0)
								&& y + j1 > 0) {
							recur(w, p, x + i1, y + j1, z + k1, b, i + 1);
						}
					}
				}
			}
			if (!w.isRemote) {
				if (!(p.capabilities.isCreativeMode)
						&& w.getBlock(x, y, z) == b) {
					p.inventory.addItemStackToInventory(new ItemStack(b
							.getItemDropped(1, itemRand, 0), b
							.quantityDropped(itemRand), b.damageDropped(0)));
				}
				if (y > 0) {
					w.setBlock(x, y, z, Blocks.air);
				}
			}
		}
		return true;
	}

	public boolean onItemUse(ItemStack i, EntityPlayer p, World w, int x,
			int y, int z, int p_77648_7_, float p_77648_8_, float p_77648_9_,
			float p_77648_10_) {
		String h = w.getBlock(x, y, z).getHarvestTool(w.getBlockMetadata(x, y, z));
		if (h == null || h == "axe") {
			recur(w, p, x, y, z, w.getBlock(x, y, z), 0);
			p.inventoryContainer.detectAndSendChanges();
			return true;
		}
		return false;
	}

}
