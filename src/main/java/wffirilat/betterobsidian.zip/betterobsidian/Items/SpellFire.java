package wffirilat.betterobsidian.Items;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;
import wffirilat.betterobsidian.Blocks.ModBlocks;
import wffirilat.betterobsidian.lib.Constants;
import cpw.mods.fml.common.registry.GameRegistry;

public class SpellFire extends Item {

	private String name = "fireSpell";

	public SpellFire() {

		setUnlocalizedName(Constants.MODID + "_" + name);
		setTextureName(Constants.MODID + ":" + name);
		GameRegistry.registerItem(this, name);
		setCreativeTab(CreativeTabs.tabMaterials);
		this.bFull3D = true;
	}

	int radius = 20;
	int cost = 12;

	public boolean onItemUse(ItemStack iS, EntityPlayer p, World w, int x, int y, int z, int p_77648_7_, float p_77648_8_, float p_77648_9_, float p_77648_10_) {
		if (MagicItem.expendMagic(p, cost)) {
			for (int i = -radius; i <= radius; i++) {
				for (int j = -radius; j <= radius; j++) {
					if (w.getBlock(x + i, y + 1, z + j) == Blocks.air && w.getBlock(x + i, y, z + j) != Blocks.air && (Math.sqrt((i * i) + (j * j)) <= radius)) {
						w.setBlock(x + i, y + 1, z + j, ModBlocks.mageFire);
					}
				}
			}
		}
		return false;
	}
}
