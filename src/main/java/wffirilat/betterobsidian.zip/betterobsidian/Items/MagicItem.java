package wffirilat.betterobsidian.Items;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import wffirilat.betterobsidian.lib.Constants;
import cpw.mods.fml.common.registry.GameRegistry;

public class MagicItem extends Item {

	private String name = "magic";

	public MagicItem() {

		setUnlocalizedName(Constants.MODID + "_" + name);
		setTextureName(Constants.MODID + ":" + name);
		GameRegistry.registerItem(this, name);
		setCreativeTab(CreativeTabs.tabMaterials);
	}

	public static boolean splitMagic(EntityPlayer p) {
		if (p.inventory.hasItem(ModItems.magic)) {
			return true;
		} else if (p.inventory.hasItem(ModItems.bigMagic)) {
			if (p.inventory.addItemStackToInventory(new ItemStack(ModItems.magic, 9))) {
				p.inventory.consumeInventoryItem(ModItems.bigMagic);
				return true;
			} else {
				return false;
			}
		} else if (p.inventory.hasItem(ModItems.hugeMagic)) {
			if (p.inventory.addItemStackToInventory(new ItemStack(ModItems.bigMagic, 9))) {
				p.inventory.consumeInventoryItem(ModItems.hugeMagic);
				if (p.inventory.addItemStackToInventory(new ItemStack(ModItems.magic, 9))) {
					p.inventory.consumeInventoryItem(ModItems.bigMagic);
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}
		return true;
	}

	public static boolean expendMagic(EntityPlayer p, int n) {
		InventoryPlayer i = p.inventory;
		if (!p.capabilities.isCreativeMode) {
			for (int j = 0; j < n; j++) {
				if (i.hasItem(ModItems.magic)) {
					i.consumeInventoryItem(ModItems.magic);
				} else if (splitMagic(p)) {
					if (!i.consumeInventoryItem(ModItems.magic)) {
						refundMagic(p,j);
						return false;
					}
				} else {
					refundMagic(p,j);
					return false;
				}
			}
			p.inventoryContainer.detectAndSendChanges();
		}
		return true;
	}

	public static boolean refundMagic(EntityPlayer p, int n) {
		while (n > 0) {
			if (n >= 81) {
				p.inventory.addItemStackToInventory(new ItemStack(ModItems.hugeMagic));
				n -= 81;
			} else if (n >= 9) {
				p.inventory.addItemStackToInventory(new ItemStack(ModItems.bigMagic));
				n -= 9;
			} else {
				p.inventory.addItemStackToInventory(new ItemStack(ModItems.magic));
				n -= 1;
			}

		}
		return true;
	}

}
