package wffirilat.betterobsidian.Items;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import wffirilat.betterobsidian.Mobs.Voidling;
import wffirilat.betterobsidian.lib.Constants;
import cpw.mods.fml.common.registry.GameRegistry;

public class RainbowFossil extends Item {
	
    private String name = "rainbowFossil";
    
    public RainbowFossil() {
        
        setUnlocalizedName(Constants.MODID + "_" + name);
        setTextureName(Constants.MODID + ":" + name);
        GameRegistry.registerItem(this, name);
        setCreativeTab(CreativeTabs.tabMaterials);
    }
    
    @Override
    public ItemStack onItemRightClick(ItemStack i , World w, EntityPlayer p){
    	if(!p.capabilities.isCreativeMode){--i.stackSize;}
    	if(!w.isRemote){
    		w.spawnParticle("smoke", p.posX, p.posY, p.posZ, 0.0D, 0.0D, 0.0D);
    	}
    	return i;
    }
}
