package naruto1310.extendedWorkbench.item;

import static naruto1310.extendedWorkbench.ExtendedWorkbench.extendedValues.increaseFlintAndSteelDurability;
import naruto1310.extendedWorkbench.block.BlockExtendedFire;
import net.minecraft.block.BlockDispenser;
import net.minecraft.dispenser.BehaviorDefaultDispenseItem;
import net.minecraft.dispenser.IBlockSource;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemFlintAndSteel;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;

public class ItemExtendedFlintAndSteel extends ItemFlintAndSteel
{
    public ItemExtendedFlintAndSteel()
    {
        super();
        this.setMaxDamage((int)(getMaxDamage() * increaseFlintAndSteelDurability));
		BlockDispenser.dispenseBehaviorRegistry.putObject(this, new BehaviorDefaultDispenseItem()
        {
            @Override
			protected ItemStack dispenseStack(IBlockSource source, ItemStack stack)
            {
                EnumFacing enumfacing = BlockDispenser.func_149937_b(source.getBlockMetadata());
                World world = source.getWorld();
                int i = source.getXInt() + enumfacing.getFrontOffsetX();
                int j = source.getYInt() + enumfacing.getFrontOffsetY();
                int k = source.getZInt() + enumfacing.getFrontOffsetZ();

                if(world.isAirBlock(i, j, k))
                {
                    world.setBlock(i, j, k, Blocks.fire);
                    BlockExtendedFire.setExtended(i, j, k, true);

                    if(stack.attemptDamageItem(1, world.rand))
                        stack.stackSize = 0;
                }
                else if(world.getBlock(i, j, k) == Blocks.tnt)
                {
                    Blocks.tnt.onBlockDestroyedByPlayer(world, i, j, k, 1);
                    world.setBlockToAir(i, j, k);
                }

                return stack;
            }
        });
    }

    @Override
    public boolean onItemUse(ItemStack stack, EntityPlayer player, World world, int x, int y, int z, int side, float f0, float f1, float f2)
    {
    	if(super.onItemUse(stack, player, world, x, y, z, side, f0, f1, f2))
    	{
    		BlockExtendedFire.setExtended(x, y, z, true);
    		return true;
    	}
    	return false;
    }

    @Override
    public boolean itemInteractionForEntity(ItemStack stack, EntityPlayer player, EntityLivingBase entity)
    {
    	entity.attackEntityFrom(DamageSource.causeMobDamage(entity), 0);
        entity.setFire(8);
        entity.worldObj.playSoundAtEntity(entity, "fire.ignite", 1.0F, 1.0F);

        stack.damageItem(1, entity);
        
        return true;
    }
}
