package naruto1310.extendedWorkbench.packet;

import io.netty.buffer.ByteBuf;
import naruto1310.extendedWorkbench.ExtendedWorkbench;
import naruto1310.extendedWorkbench.item.ExtendedMapData;
import naruto1310.extendedWorkbench.item.ItemExtendedMap;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;

public class PacketMapUpdate implements IMessage
{
	private ItemStack send_stack;
	private World send_world;
	private EntityPlayer send_player;
	
	protected short get_uniqueID;
	protected byte[] get_itemData;

	public PacketMapUpdate() {}
	
	public PacketMapUpdate(ItemStack stack, World world, EntityPlayer player)
	{
		this.send_stack = stack;
		this.send_world = world;
		this.send_player = player;
	}
	
	@Override
	public void fromBytes(ByteBuf buf)
	{
		this.get_uniqueID = buf.readShort();
		if(this.get_uniqueID == -1)
			return;
		short s = buf.readShort();
		this.get_itemData = new byte[s];
		for(int i = 0; i < s; i++)
			this.get_itemData[i] = buf.readByte();
	}

	@Override
	public void toBytes(ByteBuf buf)
	{
		if(this.send_stack == null || this.send_world == null || this.send_player == null)
			return;
		
		byte[] colors = ((ItemExtendedMap)ExtendedWorkbench.extendedMap).getMapData(this.send_stack, this.send_world).getUpdatePacketData(this.send_stack, this.send_world, this.send_player);
    	
    	if(colors == null)
    	{
    		buf.writeShort((short)-1);
    		return;
    	}
    	
		buf.writeShort((short)this.send_stack.getItemDamage());
		buf.writeShort((short)colors.length);
		for(int i = 0; i < colors.length; i++)    			
			buf.writeByte(colors[i]);		
	}
	
	public static class Handler implements IMessageHandler<PacketMapUpdate, IMessage>
	{
		@Override
		public IMessage onMessage(PacketMapUpdate message, MessageContext ctx)
		{
			if(message.get_uniqueID != -1)
			{
				ExtendedMapData map = ItemExtendedMap.getMPMapData(message.get_uniqueID, ExtendedWorkbench.proxy.getClientWorld());
				map.updateMPMapData(message.get_itemData);
				
				//I spend one week trying to figure out what was wrong until I noticed that I had to add this line. #notcoolMojang
				Minecraft.getMinecraft().entityRenderer.getMapItemRenderer().func_148246_a(map);
			}
			return null;
		}
		
	}
}

