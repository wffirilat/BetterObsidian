package naruto1310.extendedWorkbench.packet;

import io.netty.buffer.ByteBuf;
import naruto1310.extendedWorkbench.ExtendedWorkbench;
import naruto1310.extendedWorkbench.item.ExtendedMapData;
import naruto1310.extendedWorkbench.item.ItemExtendedMap;
import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;

public class PacketMapZoomReply implements IMessage
{
	private short send_uniqueID;
	private ExtendedMapData send_map;

	protected short get_uniqueID;
	protected byte[] get_colors;
	protected byte get_scale;

	public PacketMapZoomReply()
	{
		this((short)-1, null);
	}
	
	public PacketMapZoomReply(short uniqueID, ExtendedMapData map)
	{
		this.send_uniqueID = uniqueID;
		this.send_map = map;
	}

	@Override
	public void toBytes(ByteBuf buf)
	{
		if(this.send_uniqueID == -1 || this.send_map == null)
			return;
		
		// send whole color array to client
		byte[] colors = this.send_map.colors;

		buf.writeShort(this.send_uniqueID);
		buf.writeShort((short) colors.length);
		for (int i = 0; i < colors.length; i++)
			buf.writeByte(colors[i]);
		buf.writeByte(this.send_map.scale);
	}

	@Override
	public void fromBytes(ByteBuf buf)
	{
		this.get_uniqueID = buf.readShort();
		short s = buf.readShort();
		this.get_colors = new byte[s];
		for (int i = 0; i < s; i++)
			this.get_colors[i] = buf.readByte();
		this.get_scale = buf.readByte();
	}

	public static class Handler implements IMessageHandler<PacketMapZoomReply, IMessage>
	{
		@Override
		public IMessage onMessage(PacketMapZoomReply message, MessageContext ctx)
		{
			ExtendedMapData map = ItemExtendedMap.getMPMapData(message.get_uniqueID, ExtendedWorkbench.proxy.getClientWorld());
			map.setScale(message.get_scale);
			map.colors = message.get_colors;
			return null;
		}
	}
}
