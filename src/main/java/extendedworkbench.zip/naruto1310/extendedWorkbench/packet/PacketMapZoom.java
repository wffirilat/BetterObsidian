package naruto1310.extendedWorkbench.packet;

import io.netty.buffer.ByteBuf;
import naruto1310.extendedWorkbench.item.ExtendedMapData;
import naruto1310.extendedWorkbench.item.ItemExtendedMap;
import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;

public class PacketMapZoom implements IMessage
{
	private boolean send_in;
	private short send_uniqueID;
	
	protected short get_uniqueID;
	protected byte get_in;

	public PacketMapZoom() {}
	
	public PacketMapZoom(short uniqueID, boolean in)
	{
		this.send_uniqueID = uniqueID;
		this.send_in = in;
	}
	
	@Override
	public void toBytes(ByteBuf buf)
	{
		if(this.send_uniqueID == -1)
			return;
		
		buf.writeShort(this.send_uniqueID);
		if(this.send_in)
			buf.writeByte(1);
		else
			buf.writeByte(3);
	}

	@Override
	public void fromBytes(ByteBuf buf)
	{
		this.get_uniqueID = buf.readShort();
		this.get_in = buf.readByte();
	}

	public static class Handler implements IMessageHandler<PacketMapZoom, PacketMapZoomReply>
	{
		@Override
		public PacketMapZoomReply onMessage(PacketMapZoom message, MessageContext ctx)
		{
			ExtendedMapData map = ItemExtendedMap.getMPMapData(message.get_uniqueID, ctx.getServerHandler().playerEntity.worldObj);
			map.setScale(map.scale + (message.get_in - 2));
	
			//send updated colors back
			return new PacketMapZoomReply(message.get_uniqueID, map);
		}
	}
}
