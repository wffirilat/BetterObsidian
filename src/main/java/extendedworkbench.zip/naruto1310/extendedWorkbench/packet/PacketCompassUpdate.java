package naruto1310.extendedWorkbench.packet;

import io.netty.buffer.ByteBuf;
import naruto1310.extendedWorkbench.ExtendedWorkbench;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;

public class PacketCompassUpdate implements IMessage
{
	private NBTTagCompound send_nbt;
	protected NBTTagCompound get_nbt;
	
	public PacketCompassUpdate() {}
	
	public PacketCompassUpdate(NBTTagCompound nbt)
	{
		this.send_nbt = nbt;
	}

	@Override
	public void fromBytes(ByteBuf buf)
	{
		this.get_nbt = new NBTTagCompound();
		this.get_nbt.setLong("lastUpdate", buf.readLong());
		this.get_nbt.setBoolean("drawSpawnNeedle", buf.readBoolean());
		int mk = buf.readByte();
		for(int k = 0; k < mk; k++)
		{
			byte b = buf.readByte();
			String s = "";
			for(int i = 0 ; i < b; i++)
				s = s + buf.readChar();
			if(!s.isEmpty())
				this.get_nbt.setString("needle" + k, s);
		}		
	}

	@Override
	public void toBytes(ByteBuf buf)
	{
		if(this.send_nbt == null)
			return;
		
		buf.writeLong(this.send_nbt.getLong("lastUpdate"));
    	buf.writeBoolean(this.send_nbt.getBoolean("drawSpawnNeedle"));
    	int mk = -1;
    	for(int k = 0; k < 4; k++)
    		if(this.send_nbt.hasKey("needle" + k))
    			mk = k + 1;
    	buf.writeByte(mk);
	    for(int k = 0; k < mk; k++)
	    {
	    	String s = this.send_nbt.getString("needle" + k);
	    	buf.writeByte((byte)s.length());
	    	for(int i = 0; i < s.length(); i++)
	    		buf.writeChar(s.charAt(i));
	    }
	}
	
	public static class Handler implements IMessageHandler<PacketCompassUpdate, IMessage>
	{
		@Override
		public IMessage onMessage(PacketCompassUpdate message, MessageContext ctx)
		{
			ItemStack stack = ctx.getServerHandler().playerEntity.getCurrentEquippedItem();
			if(stack != null && stack.getItem() == ExtendedWorkbench.extendedCompass)
			{
				stack.setTagCompound(message.get_nbt);
				ctx.getServerHandler().playerEntity.inventory.setInventorySlotContents(ctx.getServerHandler().playerEntity.inventory.currentItem, stack);
			}
			return null;
		}
	}
}
