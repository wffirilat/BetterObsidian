package naruto1310.extendedWorkbench.crafting;

import net.minecraft.item.crafting.IRecipe;

public interface IExtendedRecipe extends IRecipe
{
}
