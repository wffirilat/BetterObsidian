package naruto1310.extendedWorkbench.crafting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import net.minecraft.block.Block;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.ShapedRecipes;
import net.minecraft.world.World;
import net.minecraftforge.oredict.OreDictionary;

public class ExtendedShapedOreRecipe implements IExtendedRecipe
{
    private static final int MAX_CRAFT_GRID_WIDTH = 3;
    private static final int MAX_CRAFT_GRID_HEIGHT = 6;

    private ItemStack output = null;
    protected Object[] input = null;
    protected int width = 0;
    protected int height = 0;
    private boolean mirrored = true;

    public ExtendedShapedOreRecipe(Block     result, Object... recipe){ this(new ItemStack(result), recipe); }
    public ExtendedShapedOreRecipe(Item      result, Object... recipe){ this(new ItemStack(result), recipe); }
    public ExtendedShapedOreRecipe(ItemStack result, Object... recipe)
    {
        this.output = result.copy();

        String shape = "";
        int idx = 0;

        if (recipe[idx] instanceof Boolean)
        {
            this.mirrored = (Boolean)recipe[idx];
            if (recipe[idx+1] instanceof Object[])
            {
                recipe = (Object[])recipe[idx+1];
            }
            else
            {
                idx = 1;
            }
        }

        if (recipe[idx] instanceof String[])
        {
            String[] parts = ((String[])recipe[idx++]);

            for (String s : parts)
            {
                this.width = s.length();
                shape += s;
            }

            this.height = parts.length;
        }
        else
        {
            while (recipe[idx] instanceof String)
            {
                String s = (String)recipe[idx++];
                shape += s;
                this.width = s.length();
                this.height++;
            }
        }

        if (this.width * this.height != shape.length())
        {
            String ret = "Invalid shaped ore recipe: ";
            for (Object tmp :  recipe)
            {
                ret += tmp + ", ";
            }
            ret += this.output;
            throw new RuntimeException(ret);
        }

        HashMap<Character, Object> itemMap = new HashMap<Character, Object>();

        for (; idx < recipe.length; idx += 2)
        {
            Character chr = (Character)recipe[idx];
            Object in = recipe[idx + 1];

            if (in instanceof ItemStack)
            {
                itemMap.put(chr, ((ItemStack)in).copy());
            }
            else if (in instanceof Item)
            {
                itemMap.put(chr, new ItemStack((Item)in));
            }
            else if (in instanceof Block)
            {
                itemMap.put(chr, new ItemStack((Block)in, 1, OreDictionary.WILDCARD_VALUE));
            }
            else if (in instanceof String)
            {
                itemMap.put(chr, OreDictionary.getOres((String)in));
            }
            else
            {
                String ret = "Invalid shaped ore recipe: ";
                for (Object tmp :  recipe)
                {
                    ret += tmp + ", ";
                }
                ret += this.output;
                throw new RuntimeException(ret);
            }
        }

        this.input = new Object[this.width * this.height];
        int x = 0;
        for (char chr : shape.toCharArray())
        {
            this.input[x++] = itemMap.get(chr);
        }
    }

    ExtendedShapedOreRecipe(ShapedRecipes recipe, Map<ItemStack, String> replacements)
    {
        this.output = recipe.getRecipeOutput();
        this.width = recipe.recipeWidth;
        this.height = recipe.recipeHeight;

        this.input = new Object[recipe.recipeItems.length];

        for(int i = 0; i < this.input.length; i++)
        {
            ItemStack ingred = recipe.recipeItems[i];

            if(ingred == null) continue;

            this.input[i] = recipe.recipeItems[i];

            for(Entry<ItemStack, String> replace : replacements.entrySet())
            {
                if(OreDictionary.itemMatches(replace.getKey(), ingred, true))
                {
                    this.input[i] = OreDictionary.getOres(replace.getValue());
                    break;
                }
            }
        }
    }

    /**
     * Returns an Item that is the result of this recipe
     */
    @Override
    public ItemStack getCraftingResult(InventoryCrafting var1){ return this.output.copy(); }

    /**
     * Returns the size of the recipe area
     */
    @Override
    public int getRecipeSize(){ return this.input.length; }

    @Override
    public ItemStack getRecipeOutput(){ return this.output; }

    /**
     * Used to check if a recipe matches current crafting inventory
     */
    @Override
    public boolean matches(InventoryCrafting inv, World world)
    {
        for (int x = 0; x <= MAX_CRAFT_GRID_WIDTH - this.width; x++)
        {
            for (int y = 0; y <= MAX_CRAFT_GRID_HEIGHT - this.height; ++y)
            {
                if (checkMatch(inv, x, y, false))
                {
                    return true;
                }

                if (this.mirrored && checkMatch(inv, x, y, true))
                {
                    return true;
                }
            }
        }

        return false;
    }

    @SuppressWarnings("unchecked")
    private boolean checkMatch(InventoryCrafting inv, int startX, int startY, boolean mirror)
    {
        for (int x = 0; x < MAX_CRAFT_GRID_WIDTH; x++)
        {
            for (int y = 0; y < MAX_CRAFT_GRID_HEIGHT; y++)
            {
                int subX = x - startX;
                int subY = y - startY;
                Object target = null;

                if (subX >= 0 && subY >= 0 && subX < this.width && subY < this.height)
                {
                    if (mirror)
                    {
                        target = this.input[this.width - subX - 1 + subY * this.width];
                    }
                    else
                    {
                        target = this.input[subX + subY * this.width];
                    }
                }

                ItemStack slot = inv.getStackInRowAndColumn(x, y);

                if (target instanceof ItemStack)
                {
                    if (!OreDictionary.itemMatches((ItemStack)target, slot, false))
                    {
                        return false;
                    }
                }
                else if (target instanceof ArrayList)
                {
                    boolean matched = false;

                    Iterator<ItemStack> itr = ((ArrayList<ItemStack>)target).iterator();
                    while (itr.hasNext() && !matched)
                    {
                        matched = OreDictionary.itemMatches(itr.next(), slot, false);
                    }

                    if (!matched)
                    {
                        return false;
                    }
                }
                else if (target == null && slot != null)
                {
                    return false;
                }
            }
        }

        return true;
    }

    public ExtendedShapedOreRecipe setMirrored(boolean mirror)
    {
        this.mirrored = mirror;
        return this;
    }

    /**
     * Returns the input for this recipe, any mod accessing this value should never
     * manipulate the values in this array as it will effect the recipe itself.
     * @return The recipes input vales.
     */
    public Object[] getInput()
    {
        return this.input;
    }
}