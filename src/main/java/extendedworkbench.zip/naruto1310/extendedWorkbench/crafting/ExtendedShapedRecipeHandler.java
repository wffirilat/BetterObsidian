package naruto1310.extendedWorkbench.crafting;

import java.util.ArrayList;
import java.util.List;

import naruto1310.extendedWorkbench.block.GuiExtended;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.inventory.Container;
import net.minecraft.item.ItemStack;
import net.minecraftforge.oredict.OreDictionary;

import org.lwjgl.opengl.GL11;

import codechicken.lib.gui.GuiDraw;
import codechicken.nei.NEIServerUtils;
import codechicken.nei.PositionedStack;
import codechicken.nei.recipe.RecipeInfo;
import codechicken.nei.recipe.ShapedRecipeHandler;

public class ExtendedShapedRecipeHandler extends ShapedRecipeHandler
{
	public class CachedExtendedRecipe extends CachedRecipe
	{
		public CachedExtendedRecipe(ExtendedShapedRecipes recipe)
		{
			this(recipe.recipeWidth, recipe.recipeHeight, recipe.recipeItems, recipe.getRecipeOutput());
		}
		
		public CachedExtendedRecipe(int width, int height, Object[] items, ItemStack out)
		{
			this.result = new PositionedStack(out, 119, 52);
			this.ingredients = new ArrayList<PositionedStack>();
			setIngredients(width, height, items);
		}
			
		public void setIngredients(int width, int height, Object[] items)
		{			
			for(int x = 0; x < width; x++)
			{
				for(int y = 0; y < height; y++)
				{
					if(items[y * width + x] == null)
					{
						continue;
					}
					PositionedStack stack = new PositionedStack(items[y * width + x], 25 + x * 18, 6 + y * 18);
					stack.setMaxSize(1);
					this.ingredients.add(stack);
				}
			}
		}
		
		@Override
		public ArrayList<PositionedStack> getIngredients()
		{
			return (ArrayList<PositionedStack>) getCycledIngredients(ExtendedShapedRecipeHandler.this.cycleticks / 20, this.ingredients);
		}
		
		@Override
		public PositionedStack getResult()
		{
			return this.result;
		}
		
		public ArrayList<PositionedStack> ingredients;
		public PositionedStack result;
	}
	
	public class CachedExtendedOreRecipe extends CachedRecipe
	{
		public CachedExtendedOreRecipe(ExtendedShapedOreRecipe recipe)
		{
			this(recipe.width, recipe.height, recipe.input, recipe.getRecipeOutput());
		}
		
		public CachedExtendedOreRecipe(int width, int height, Object[] items, ItemStack out)
		{
			this.result = new PositionedStack(out, 119, 52);
			this.ingredients = new ArrayList<PositionedStack>();
			setIngredients(width, height, items);
		}
			
		public void setIngredients(int width, int height, Object[] items)
		{			
			for(int x = 0; x < width; x++)
			{
				for(int y = 0; y < height; y++)
				{
					Object item = items[y * width + x];
					if(item == null)
					{
						continue;
					}
					if(item instanceof String)
					{
						item = OreDictionary.getOres((String)item).get(0);
					}
					PositionedStack stack = new PositionedStack(item, 25 + x * 18, 6 + y * 18);
					stack.setMaxSize(1);
					this.ingredients.add(stack);
				}
			}
		}
		
		@Override
		public ArrayList<PositionedStack> getIngredients()
		{
			return (ArrayList<PositionedStack>) getCycledIngredients(ExtendedShapedRecipeHandler.this.cycleticks / 20, this.ingredients);
		}
		
		@Override
		public PositionedStack getResult()
		{
			return this.result;
		}
		
		public ArrayList<PositionedStack> ingredients;
		public PositionedStack result;
	}

	@Override
	public int recipiesPerPage()
	{
		return 1;
	}
	
	@Override
	public Class<? extends GuiContainer> getGuiClass()
	{
		return GuiExtended.class;
	}

	@Override
	public String getRecipeName()
	{
		return "Extended Crafting";
	}
	
	@Override
	public void loadCraftingRecipes(String outputId, Object... results)
	{
		if(outputId.equals("extended") && getClass() == ExtendedShapedRecipeHandler.class)
		{
			List<IExtendedRecipe> allrecipes = ExtendedCraftingManager.getInstance().getRecipeList();
			for(IExtendedRecipe irecipe : allrecipes)
			{
				CachedRecipe recipe = null;
				if(irecipe instanceof ExtendedShapedRecipes)
					recipe = new CachedExtendedRecipe((ExtendedShapedRecipes)irecipe);
				if(irecipe instanceof ExtendedShapedOreRecipe)
					recipe = new CachedExtendedOreRecipe((ExtendedShapedOreRecipe)irecipe);

				if(recipe == null)
					continue;
				
				this.arecipes.add(recipe);
			}
		}
		else
		{
			super.loadCraftingRecipes(outputId, results);
		}
	}
	
	@Override
	public void loadCraftingRecipes(ItemStack result)
	{
		List<IExtendedRecipe> allrecipes = ExtendedCraftingManager.getInstance().getRecipeList();
		for(IExtendedRecipe irecipe : allrecipes)
		{
			if(NEIServerUtils.areStacksSameTypeCrafting(irecipe.getRecipeOutput(), result))
			{
				CachedRecipe recipe = null;
				if(irecipe instanceof ExtendedShapedRecipes)
					recipe = new CachedExtendedRecipe((ExtendedShapedRecipes)irecipe);
				if(irecipe instanceof ExtendedShapedOreRecipe)
					recipe = new CachedExtendedOreRecipe((ExtendedShapedOreRecipe)irecipe);
				
				if(recipe == null)
					continue;
				
				this.arecipes.add(recipe);
			}
		}
	}
	
	@Override
	public void loadUsageRecipes(ItemStack ingredient)
	{
		List<IExtendedRecipe> allrecipes = ExtendedCraftingManager.getInstance().getRecipeList();
		for(IExtendedRecipe irecipe : allrecipes)
		{
			if(irecipe instanceof ExtendedShapedRecipes)
			{
				CachedExtendedRecipe recipe = new CachedExtendedRecipe((ExtendedShapedRecipes)irecipe);
				if(recipe.contains(recipe.ingredients, ingredient))
				{
					recipe.setIngredientPermutation(recipe.ingredients, ingredient);
					if(!this.arecipes.contains(recipe))
						this.arecipes.add(recipe);
				}
			}
			
			if(irecipe instanceof ExtendedShapedOreRecipe)
			{
				CachedExtendedOreRecipe recipe = new CachedExtendedOreRecipe((ExtendedShapedOreRecipe)irecipe);
				for(Object o : ((ExtendedShapedOreRecipe)irecipe).input)
				{
					if(o != null)
					{
						if(o instanceof ItemStack)
						{
							if(((ItemStack)o).getItem() == ingredient.getItem())
							{
								recipe.setIngredientPermutation(recipe.ingredients, ingredient);
								if(!this.arecipes.contains(recipe))
									this.arecipes.add(recipe);
							}
						}
						//TODO fix in 1.8
						if(o instanceof List)
						{
							for(Object stack : (List)o)
							{
								if(stack instanceof ItemStack && ((ItemStack)stack).getItem() == ingredient.getItem())
								{
									recipe.setIngredientPermutation(recipe.ingredients, ingredient);
									if(!this.arecipes.contains(recipe))
										this.arecipes.add(recipe);
								}
							}
						}
					}
				}
			}
		}
	}

	@Override
	public String getGuiTexture()
	{
		return "extendedworkbench:textures/gui/container/extended.png";
	}

	@Override
	public boolean hasOverlay(GuiContainer gui, Container container, int recipe)
	{
		return RecipeInfo.hasDefaultOverlay(gui, "extended");
	}
	
	@Override
    public void drawBackground(int recipe)
    {
        GL11.glColor4f(1, 1, 1, 1);
        GuiDraw.changeTexture(getGuiTexture());
        GuiDraw.drawTexturedModalRect(0, 0, 5, 11, 166, 119);
    }
}
