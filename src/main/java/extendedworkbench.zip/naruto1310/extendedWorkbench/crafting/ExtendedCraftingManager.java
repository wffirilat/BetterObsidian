package naruto1310.extendedWorkbench.crafting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import net.minecraft.block.Block;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.world.World;

public class ExtendedCraftingManager
{
    /** The static instance of this class */
    private static ExtendedCraftingManager instance = null;

    /** A list of all the recipes added */
    private List<IExtendedRecipe> recipes = new ArrayList<IExtendedRecipe>();

    /**
     * Returns the static instance of this class
     */
    public static final ExtendedCraftingManager getInstance()
    {
    	if(instance == null)
    		instance = new ExtendedCraftingManager();
        return instance;
    }

    private void addExtendedRecipe(ItemStack result, Object ... recipe)
    {
        String string = "";
        int zero = 0;
        int int1 = 0;
        int int2 = 0;

        if(recipe[zero] instanceof String[])
        {
            String[] strArray = ((String[])recipe[zero++]);

            for(int i = 0; i < strArray.length; ++i)
            {
                String index = strArray[i];
                ++int2;
                int1 = index.length();
                string = string + index;
            }
        }
        else
        {
            while(recipe[zero] instanceof String)
            {
                String var11 =(String)recipe[zero++];
                ++int2;
                int1 = var11.length();
                string = string + var11;
            }
        }

        HashMap<Character, ItemStack> hash;

        for(hash = new HashMap<Character, ItemStack>(); zero < recipe.length; zero += 2)
        {
            Character var13 =(Character)recipe[zero];
            ItemStack var14 = null;

            if(recipe[zero + 1] instanceof Item)
                var14 = new ItemStack((Item)recipe[zero + 1], 1, 32767);
            if(recipe[zero + 1] instanceof Block)
                var14 = new ItemStack((Block)recipe[zero + 1], 1, 32767);
            if(recipe[zero + 1] instanceof ItemStack)
                var14 =(ItemStack)recipe[zero + 1];

            hash.put(var13, var14);
        }

        ItemStack[] var15 = new ItemStack[int1 * int2];

        for(int var16 = 0; var16 < int1 * int2; ++var16)
        {
            char var10 = string.charAt(var16);

            if(hash.containsKey(Character.valueOf(var10)))
                var15[var16] = hash.get(Character.valueOf(var10)).copy();
            else
                var15[var16] = null;
        }

        this.recipes.add(new ExtendedShapedRecipes(int1, int2, var15, result));
    }

    private void addExtendedShapelessRecipe(ItemStack par1ItemStack, Object ... par2ArrayOfObj)
    {
        ArrayList<ItemStack> var3 = new ArrayList<ItemStack>();
        Object[] var4 = par2ArrayOfObj;
        int var5 = par2ArrayOfObj.length;

        for(int var6 = 0; var6 < var5; var6++)
        {
            Object var7 = var4[var6];

            if(var7 instanceof Item)
                var3.add(new ItemStack((Item)var7, 1, 32767));
            else if(var7 instanceof Block)
                var3.add(new ItemStack((Block)var7, 1, 32767));
            else if(var7 instanceof ItemStack)
            	var3.add(((ItemStack)var7).copy());
            else throw new RuntimeException("Invalid shapeless recipe!");
        }

        this.recipes.add(new ExtendedShapelessRecipes(par1ItemStack, var3));
    }

    public ItemStack findMatchingRecipe(InventoryCrafting inv, World world)
    {
        for(int i = 0; i < this.recipes.size(); i++)
        {
            IRecipe recipe = this.recipes.get(i);
            
            if(recipe.matches(inv, world))
            	return recipe.getCraftingResult(inv);
        }

        return null;
    }

    public List<IExtendedRecipe> getRecipeList()
    {
        return this.recipes;
    }

    public static void addRecipe(ItemStack output, Object ... input)
    {
        ExtendedCraftingManager.getInstance().addExtendedRecipe(output, input);
    }

    public static void addShapelessRecipe(ItemStack output, Object ... input)
    {
        ExtendedCraftingManager.getInstance().addExtendedShapelessRecipe(output, input);
    }   
    
    public static void addOreRecipe(ItemStack output, Object ... input)
    {
        ExtendedCraftingManager.getInstance().recipes.add(new ExtendedShapedOreRecipe(output, input));
    }

    //we don't really need extended shapeless recipes, right?
}
