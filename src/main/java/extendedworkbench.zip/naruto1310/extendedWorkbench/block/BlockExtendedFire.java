package naruto1310.extendedWorkbench.block;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.BlockFire;
import net.minecraft.world.World;

public class BlockExtendedFire extends BlockFire
{
	private static List<String> extendedFires = new ArrayList<String>();
	
	public BlockExtendedFire()
	{
		super();
		this.disableStats();
	}
	
	@Override
    public void updateTick(World world, int x, int y, int z, Random rand)
    {
		if(isExtended(x, y, z))
		{
			float rainStrength = world.getRainStrength(0);
			world.setRainStrength(0);
			int metadata = world.getBlockMetadata(x, y, z);
			
			super.updateTick(world, x, y, z, rand);
			
			world.setRainStrength(rainStrength);
			if(world.isAirBlock(x, y, z))
				setExtended(x, y, z, false);
			else
				if(rand.nextBoolean())
					world.setBlockMetadataWithNotify(x, y, z, metadata, 4);
		}
		else
			super.updateTick(world, x, y, z, rand);
    }
	
	@Override
	public void breakBlock(World world, int x, int y, int z, Block block, int meta)
	{
		super.breakBlock(world, x, y, z, block, meta);
		BlockExtendedFire.setExtended(x, y, z, false);
	}

	private boolean isExtended(int x, int y, int z)
	{
		return extendedFires.contains(x + ":" + y + ":" + z);
	}
	
	public static void setExtended(int x, int y, int z, boolean extended)
	{
		String s = x + ":" + y + ":" + z;
		if(extended)
			extendedFires.add(s);
		else
			extendedFires.remove(s);
	}
}
